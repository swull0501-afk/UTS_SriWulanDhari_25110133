package dao;

import koneksi.Koneksi;
import model.Barang;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BarangDAO {

    // 1. SIMPAN DATA
    public boolean simpan(Barang b) throws SQLException {

        String sql = "INSERT INTO barang "
                + "(kode_barang, nama_barang, kategori, stok) "
                + "VALUES (?, ?, ?, ?)";

        try (Connection c = Koneksi.getConnection();
             PreparedStatement p = c.prepareStatement(sql)) {

            p.setString(1, b.getKodeBarang());
            p.setString(2, b.getNamaBarang());
            p.setString(3, b.getKategori());
            p.setInt(4, b.getStok());

            return p.executeUpdate() > 0;
        }
    }

    // 2. TAMPILKAN DATA
    public List<Barang> tampilkan() throws SQLException {

        List<Barang> data = new ArrayList<>();

        String sql = "SELECT * FROM barang";

        try (Connection c = Koneksi.getConnection();
             Statement s = c.createStatement();
             ResultSet r = s.executeQuery(sql)) {

            while (r.next()) {

                Barang b = new Barang(
                    r.getString("kode_barang"),
                    r.getString("nama_barang"),
                    r.getString("kategori"),
                    r.getInt("stok")
                );

                data.add(b);
            }
        }

        return data;
    }

    // 3. UBAH DATA
    public boolean ubah(Barang b) throws SQLException {

        String sql = "UPDATE barang SET "
                + "nama_barang=?, kategori=?, stok=? "
                + "WHERE kode_barang=?";

        try (Connection c = Koneksi.getConnection();
             PreparedStatement p = c.prepareStatement(sql)) {

            p.setString(1, b.getNamaBarang());
            p.setString(2, b.getKategori());
            p.setInt(3, b.getStok());
            p.setString(4, b.getKodeBarang());

            return p.executeUpdate() > 0;
        }
    }

    // 4. HAPUS DATA
    public boolean hapus(String kode) throws SQLException {

        String sql = "DELETE FROM barang "
                + "WHERE kode_barang=?";

        try (Connection c = Koneksi.getConnection();
             PreparedStatement p = c.prepareStatement(sql)) {

            p.setString(1, kode);

            return p.executeUpdate() > 0;
        }
    }
}