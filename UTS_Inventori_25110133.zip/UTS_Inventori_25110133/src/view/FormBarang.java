package view;

import dao.BarangDAO;
import model.Barang;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;

public class FormBarang extends JFrame {

    private JTextField txtKode, txtNama, txtStok;
    private JComboBox<String> cmbKategori;

    private JButton btnSimpan, btnUbah;
    private JButton btnHapus, btnBersihkan;

    private JTable tblBarang;
    private DefaultTableModel model;

    private BarangDAO dao = new BarangDAO();

    // CONSTRUCTOR
    public FormBarang() {

        setTitle("Aplikasi Data Barang Laboratorium");
        setSize(850, 650);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        buatTampilan();
        tampilData();
    }

    // MEMBUAT TAMPILAN
    private void buatTampilan() {

        JPanel utama = new JPanel(new BorderLayout(10, 10));

        utama.setBorder(
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        );

        // JUDUL
        JLabel judul = new JLabel(
            "PENGELOLAAN DATA BARANG LABORATORIUM",
            SwingConstants.CENTER
        );

        judul.setFont(new Font("Arial", Font.BOLD, 22));

        utama.add(judul, BorderLayout.NORTH);

        // FORM INPUT
        JPanel form = new JPanel(new GridLayout(4, 2, 10, 10));

        form.setBorder(
            BorderFactory.createTitledBorder("Form Data Barang")
        );

        txtKode = new JTextField();
        txtNama = new JTextField();
        txtStok = new JTextField();

        cmbKategori = new JComboBox<>(
            new String[]{
                "Komputer",
                "Jaringan",
                "Alat Ukur"
            }
        );

        form.add(new JLabel("Kode Barang"));
        form.add(txtKode);

        form.add(new JLabel("Nama Barang"));
        form.add(txtNama);

        form.add(new JLabel("Kategori"));
        form.add(cmbKategori);

        form.add(new JLabel("Stok"));
        form.add(txtStok);

        // TOMBOL
        btnSimpan = new JButton("Simpan");
        btnUbah = new JButton("Ubah");
        btnHapus = new JButton("Hapus");
        btnBersihkan = new JButton("Bersihkan");

        JPanel tombol = new JPanel(
            new FlowLayout(FlowLayout.CENTER, 10, 10)
        );

        tombol.add(btnSimpan);
        tombol.add(btnUbah);
        tombol.add(btnHapus);
        tombol.add(btnBersihkan);

        // GABUNG FORM DAN TOMBOL
        JPanel bagianForm = new JPanel(new BorderLayout(5, 5));

        bagianForm.add(form, BorderLayout.CENTER);
        bagianForm.add(tombol, BorderLayout.SOUTH);

        // TABEL
        model = new DefaultTableModel(
            new String[]{
                "Kode Barang",
                "Nama Barang",
                "Kategori",
                "Stok"
            }, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int col) {
                return false;
            }
        };

        tblBarang = new JTable(model);
        tblBarang.setRowHeight(25);

        JScrollPane scroll = new JScrollPane(tblBarang);

        scroll.setBorder(
            BorderFactory.createTitledBorder("Daftar Barang")
        );

        // SUSUNAN UTAMA
        JPanel isi = new JPanel(new BorderLayout(10, 10));

        isi.add(bagianForm, BorderLayout.NORTH);
        isi.add(scroll, BorderLayout.CENTER);

        utama.add(isi, BorderLayout.CENTER);

        setContentPane(utama);

        // EVENT TOMBOL
        btnSimpan.addActionListener(e -> simpanData());
        btnUbah.addActionListener(e -> ubahData());
        btnHapus.addActionListener(e -> hapusData());
        btnBersihkan.addActionListener(e -> bersihkan());

        // KLIK BARIS TABEL
        tblBarang.getSelectionModel().addListSelectionListener(e -> {

            if (!e.getValueIsAdjusting()
                    && tblBarang.getSelectedRow() != -1) {

                int baris = tblBarang.getSelectedRow();

                txtKode.setText(model.getValueAt(baris, 0).toString());
                txtNama.setText(model.getValueAt(baris, 1).toString());

                cmbKategori.setSelectedItem(
                    model.getValueAt(baris, 2).toString()
                );

                txtStok.setText(model.getValueAt(baris, 3).toString());

                txtKode.setEditable(false);
            }
        });
    }

    // VALIDASI INPUT
    private Barang ambilDataForm() {

        String kode = txtKode.getText().trim();
        String nama = txtNama.getText().trim();
        String kategori = cmbKategori.getSelectedItem().toString();
        String inputStok = txtStok.getText().trim();

        if (kode.isEmpty() || nama.isEmpty()
                || inputStok.isEmpty()) {

            JOptionPane.showMessageDialog(
                this, "Semua data wajib diisi!"
            );

            return null;
        }

        if (kode.length() > 10 || nama.length() > 50) {

            JOptionPane.showMessageDialog(
                this, "Kode maksimal 10 dan nama maksimal 50 karakter!"
            );

            return null;
        }

        int stok;

        try {

            stok = Integer.parseInt(inputStok);

            if (stok < 0) {

                JOptionPane.showMessageDialog(
                    this, "Stok tidak boleh kurang dari 0!"
                );

                return null;
            }

        } catch (NumberFormatException e) {

            JOptionPane.showMessageDialog(
                this, "Stok harus berupa angka!"
            );

            return null;
        }

        return new Barang(kode, nama, kategori, stok);
    }

    // SIMPAN
    private void simpanData() {

        Barang b = ambilDataForm();

        if (b == null) return;

        try {

            if (dao.simpan(b)) {

                JOptionPane.showMessageDialog(
                    this, "Data berhasil disimpan!"
                );

                tampilData();
                bersihkan();

            }

        } catch (SQLException e) {

            JOptionPane.showMessageDialog(
                this, "Gagal menyimpan: " + e.getMessage()
            );
        }
    }

    // UBAH
    private void ubahData() {

        if (tblBarang.getSelectedRow() == -1) {

            JOptionPane.showMessageDialog(
                this, "Pilih data terlebih dahulu!"
            );

            return;
        }

        Barang b = ambilDataForm();

        if (b == null) return;

        try {

            if (dao.ubah(b)) {

                JOptionPane.showMessageDialog(
                    this, "Data berhasil diubah!"
                );

                tampilData();
                bersihkan();

            } else {

                JOptionPane.showMessageDialog(
                    this, "Data tidak ditemukan!"
                );
            }

        } catch (SQLException e) {

            JOptionPane.showMessageDialog(
                this, "Gagal mengubah: " + e.getMessage()
            );
        }
    }

    // HAPUS
    private void hapusData() {

        if (tblBarang.getSelectedRow() == -1) {

            JOptionPane.showMessageDialog(
                this, "Pilih data yang ingin dihapus!"
            );

            return;
        }

        String kode = txtKode.getText();

        int pilihan = JOptionPane.showConfirmDialog(
            this,
            "Yakin ingin menghapus barang " + kode + "?",
            "Konfirmasi Hapus",
            JOptionPane.YES_NO_OPTION
        );

        if (pilihan == JOptionPane.YES_OPTION) {

            try {

                if (dao.hapus(kode)) {

                    JOptionPane.showMessageDialog(
                        this, "Data berhasil dihapus!"
                    );

                    tampilData();
                    bersihkan();

                } else {

                    JOptionPane.showMessageDialog(
                        this, "Data tidak ditemukan!"
                    );
                }

            } catch (SQLException e) {

                JOptionPane.showMessageDialog(
                    this, "Gagal menghapus: " + e.getMessage()
                );
            }
        }
    }

    // MENAMPILKAN DATA
    private void tampilData() {

        model.setRowCount(0);

        try {

            for (Barang b : dao.tampilkan()) {

                model.addRow(new Object[]{
                    b.getKodeBarang(),
                    b.getNamaBarang(),
                    b.getKategori(),
                    b.getStok()
                });
            }

        } catch (SQLException e) {

            JOptionPane.showMessageDialog(
                this, "Gagal menampilkan: " + e.getMessage()
            );
        }
    }

    // BERSIHKAN FORM
    private void bersihkan() {

        txtKode.setText("");
        txtNama.setText("");
        txtStok.setText("");

        cmbKategori.setSelectedIndex(0);

        tblBarang.clearSelection();

        txtKode.setEditable(true);
    }
}