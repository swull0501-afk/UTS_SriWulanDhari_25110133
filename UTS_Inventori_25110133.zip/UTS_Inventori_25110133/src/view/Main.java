package view;

public class Main {

    public static void main(String[] args) {

        java.awt.EventQueue.invokeLater(() -> {

            new FormBarang().setVisible(true);

        });
    }
}